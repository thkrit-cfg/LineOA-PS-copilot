import { createApp } from '../server/app';

// Vercel serverless function entry point.
// Exports the shared Express app as the default handler. Vercel runs this as a
// single Function; the SPA itself is served from the CDN (see vercel.json
// builds + rewrites). No app.listen() here — Vercel manages the listener.
export default createApp();
